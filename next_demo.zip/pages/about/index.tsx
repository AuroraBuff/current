import type { NextPage } from "next";



const About: NextPage = () => {
    return (
        <div>
            666
        </div>
    )
}

export default About